#!/usr/bin/env python2
"""
wta1d module, contains functions/classes to create and plot an one dimentional  winner take all network
very messy for now, helper function will be moved to other modules

@authors: Davide Plozza, Damiano Steger
"""
   
#%config IPCompleter.greedy=True
import matplotlib.pyplot as plt
import numpy as np
from scipy import ndimage
import nxsdk.api.n2a as nx
from nxsdk.utils.plotutils import plotRaster
#from nxsdk.arch.n2a import net

#Helper functions (some to be moved to other module in future)---------------------------------

#temporary (non commented) functions
def setup_spike_plot(title,wta_size,plot_begin,plot_end,index_tick_step,set_y_ticks,time_tick_step,
                     cbar_img,cbar_fraction,cbar_pad):
    plt.xlim(plot_begin,plot_end)
    if set_y_ticks:
        plt.ylim(-1,wta_size)
        loc,labels = plt.yticks(np.arange(0, wta_size, index_tick_step))
    #for label in labels[1::2]:
    #    label.set_visible(False)
    plt.xticks(np.arange(plot_begin,plot_end+1,time_tick_step)) #,labels = [])
    plt.xlabel('')
    plt.ylabel('Neuron index')
    plt.title("")
    plt.title(title,loc='left')
    plt.grid(True,axis='both',alpha = 0.5)
    plt.colorbar(cbar_img,fraction=cbar_fraction,pad=cbar_pad).ax.set_visible(False)
    
    
def plot_colormap(title,matrix,wta_size,n_plots,i_plot,plot_begin,plot_end,index_tick_step,set_y_ticks,time_tick_step,
                     cbar_img,cbar_fraction,cbar_pad,cmap='plasma'):
    ax = plt.subplot(n_plots,1,i_plot)
    im = ax.imshow(matrix,cmap = cmap, vmin=0,aspect='auto',zorder=-1,origin='lower') #aspect='auto'
    plt.yticks(np.arange(0, wta_size, index_tick_step))
    plt.xticks(np.arange(plot_begin, plot_end+1,time_tick_step))# ,labels = [])
    plt.ylabel('Neuron index')
    ax.set_title(title,loc='left')
    #plt.grid(True,alpha = 0.4)
    plt.colorbar(im,label="Firing rate [Hz]",use_gridspec=True,fraction=cbar_fraction,pad=cbar_pad)
    
def plot_input_vectors(input_vectors,color,alpha,linewidth,label=None):
    #set label only to first plot
    #return last plot handle
    i_plot = 0
    for vectors in(input_vectors):
        if (i_plot != 0):
            label = None
        if isinstance(vectors,tuple):
            plot, = plt.plot(vectors[0],vectors[1],color,alpha=alpha,linewidth=linewidth,label=label)
            i_plot += 1
        else:
            plot, = plt.plot(vectors,color,color,alpha=alpha,linewidth=linewidth,label=label)
            i_plot += 1
    return plot


#gaussian or other kernel
def make_distance_mat(size):
    """
    Creates a matrix with the (euler) distances between neurons ot a wta
    Args:
        size(int): size of the matrix

    Returns:
        float: (probability) density at a specific distance to the mean of a Gaussian distribution.
    """
    w_matrix=np.zeros((size,size))
    
    #fill with distance values
    for i in range(size):
        w_matrix[i] = abs(np.arange(0, size, 1, int) - i)
    
    return w_matrix

def normal1d_density(x, mu=0, sigma=1, normalized=True):
    """
    computes a gaussian distribution at each point x
    Args:
        x, (float): x values at which density is calculated.
        mu (float): Mean of Gaussian.
        sigma (float, optional): Standard deviation Gaussian distribution.
        normalized (bool, optional): Description

    Returns:
        density(float): (probability) density at a specific distance to the mean of a Gaussian distribution.
    """
    dist_x = x - mu
    if normalized:
        f = 1 / np.sqrt(2 * np.pi * sigma**2)
    else:
        f = 1
    if (sigma==0):
        density = np.where(dist_x==0,1,0)
    else:
        density = f * np.exp(-(1/2)*(dist_x / sigma)**2)
    #print(density)
    return density

def triangle_density(x, mu=0, sigma=1, normalized=True):
    """
    computes a "triangle" distribution at each point x
    Args:
        x, (float): x values at which density is calculated.
        mu (float): position of peak of the triangle.
        sigma (float, optional): Standard deviation: distance from the peak where the density is at half the value.
        normalized (bool, optional): Description

    Returns:
        density(float): (probability) density at a specific distance to the mean of a Gaussian distribution.
    """
    dist_x = x - mu
    if normalized:
        f = 1 / sigma**2
    else:
        f = 1
    density = f *np.maximum(1 - 0.5/sigma*np.absolute(dist_x),0)
    return density

def mexican_hat_density(x, sigma=1, normalized=True):
    """
    computes mexican hat function at points x. IMPORTANT: to have a peak of the same form of a gaussian distribution,
    the sigma has to be the double of the sigma of the gaussian dist. Actually, if you stretch/shift the gaussian down so that the
    inhibition weight is the same as the minimum of the mexican hat, the sigma of the mnexican should be (2/1.25) times the sigma 
    of the gaussian
    Args:
        x, (float): x values at which density is calculated.
        sigma (float, optional): Standard deviatio
        normalized (bool, optional): Description

    Returns:
        float: (probability) mexican hat density evaluated at x points
    """
    dist_x = x
    if normalized:
        f = 2 / (np.sqrt(3 * sigma)*(np.pi**(0.25)))
    else:
        f = 1
    density = f * (1-(dist_x/sigma)**2)*np.exp(-(1/2)*(dist_x / sigma)**2)
    #print(density)
    return density

def mexican_hat_density_2(x, sigma1=1,sigma2=1,c1=1,c2=1):
    """
    computes mexican hat function at points x. Use Difference of Gaussians (DoG) distributions instead of analytical derivation
    Args:
        x, (float): x values at which density is calculated.
        sigma1/2 (float, optional): Standard deviation of the two gaussian distributions
        c1/2: coefficents of the two gaussian distributions

    Returns:
        float: (probability) density of mexican hat distribution
    """
    dist_x = x
    
    density = c1*np.exp(-(1/2)*(dist_x / sigma1)**2) - c2*np.exp(-(1/2)*(dist_x / sigma2)**2)
    #print(density)
    return density

def make_lateral_connections(size,sigma,weight_min_peak,weight_min_global,weight_max,kernel='gaussian',self_exc = True):
    """
    creates lateral connections matrix usign gaussian or mexican hat kernels
    Args:
        kernel='gaussian' or 'mexican'. In case of mexican, weight_min shifts everything down
        weight_min_global: minimum weight of the global inhibition
        weight_min_peak: minimum weight of the minimum peaks of the mexican (DoF version), ONLY used if kernel=='mexican2'

    Returns:
        float: (probability) mexican hat density evaluated at x points
    """
    if (kernel=='gaussian'):
        w_matrix = normal1d_density(make_distance_mat(size),0,sigma,False)
    elif (kernel=='triangle'):
        w_matrix = triangle_density(make_distance_mat(size),0,sigma,False)
    elif (kernel=='mexican'):
        w_matrix = mexican_hat_density(make_distance_mat(size),sigma,False)
    elif (kernel=='mexican2'):
        #inh = 0.575
        inh = -(weight_min_peak-weight_min_global)/weight_max
        std_ratio = 1.05#2
        w_matrix = mexican_hat_density_2(make_distance_mat(size),sigma,sigma*std_ratio,1+inh,inh)
    else:
        print("kernel name not valid")
        
    w_matrix *= (weight_max - weight_min_global)
    w_matrix += weight_min_global
    
    #remove self connections if needed
    if (not self_exc):
        w_matrix = w_matrix - np.identity(size)*weight_max
    
    w_matrix = np.floor(w_matrix + 0.5)
    return w_matrix

#SPIKE and INPUT GENERATION

#Useful functions... (from synaptic plasticity tutorial)
def genRegularSpikeTimes(numSpikes=10, spikeInterval=10):
    spikeTimesBase = (np.arange(1, numSpikes) * spikeInterval)
    spikeTimes = spikeTimesBase.tolist()
    return spikeTimes

def genPoissonSpikeTimes(runTime, spikingProbability, tEpoch):
    """Generates an approximate Poisson spike train with a refractory period of tEpoch after each spike in order to avoid
    multiple spikes within the same learning epoch."""
    spikes = np.zeros((runTime, 1))
    refCtr = 0
    for i in range(runTime):
        spikes[i] = (np.random.rand(1) < spikingProbability) and refCtr <= 0
        if spikes[i]:
            refCtr = tEpoch + 1
        refCtr -= 1
    spikeTimes = np.where(spikes)[0].tolist()
    #spikeTimes = np.where(spikes)[0].
    return np.array(spikeTimes)

#new functions 
def append_regular_spikes(index,spike_times,start_step,stop_step, spike_interval,std_dev):
    """generate and append regular spike time ftrom start time to stop times (everything is in steps)
    if std dev != 0, the spikes will be gaussian distributed around theirs ideal (regualar) position
    spike_times: list of spike times arrays for all spike gen ports, index: index of spike gen port
    """
    new_spike_times = np.arange(start_step, stop_step,spike_interval)
    if (std_dev!=0):
        new_spike_times = new_spike_times + np.random.normal(0, std_dev, new_spike_times.size).astype(int)
    spike_times[index] = np.append(spike_times[index],new_spike_times)
    
def append_poisson_spikes(index,spike_times,start_step,stop_step, mean_spike_interval):
    """generate and append poisson distributed spike time ftrom start time to stop times (everything is in steps))
    Args:
        mean_spike_interval: expected interval between spikes.
        spike_times: list of spike times arrays for all spike gen ports, index: index of spike gen port
        spikingProbability = 1/(mean_spike_interval) #NO 1 because when there is a spike we "loose" one step
    """
    runTime = stop_step-start_step
    tEpoch = 0
    spikes = np.zeros((runTime, 1))
    refCtr = 0
    for i in range(runTime):
        spikes[i] = (np.random.rand(1) < spikingProbability) and refCtr <= 0
        if spikes[i]:
            refCtr = tEpoch + 1
        refCtr -= 1
    #print(spikes.sum()*1000/runTime)
    new_spike_times = np.where(spikes)[0]
    new_spike_times += start_step
    spike_times[index] = np.append(spike_times[index],new_spike_times)
    
def append_renewal_spikes(index,spike_times,start_step,stop_step,r_trials,mean_spike_interval):
    """
    generate and append negative binomially distributed distributed spike time ftrom start time to stop times
    (every arg aht to be given in steps)
    Args:
        r_trials: number of "failed" trials necessary before generating one spike.
                  if want regular spikes, set r_trials so really big number, r_trials will be automaticaly se to mean_spk_int
        mean_spike_interval: expected interval between spikes. If single value: costant mean interval, 
                              #if mean_spike_interval is a vector (of size >= stop_step-start_step), the values in the
                             #represent "instantaneous" mean_spike_interval.... which doesn't sound that good
                             #if for given time step you want the probability to be 0, set interval to negative value
        spike_times: list of spike times arrays for all spike gen ports, index: index of spike gen port
       
    """
    runTime = stop_step-start_step
    success_probability = r_trials/mean_spike_interval
    if (np.isscalar(success_probability)):
        success_probability = np.ones((runTime,)) * success_probability
    success_probability = np.where(success_probability>0,success_probability,0)#set to 0 negative values
    
    r_trials_vec = np.ones((runTime,))*r_trials
    r_trials_vec = np.where(r_trials_vec>mean_spike_interval,mean_spike_interval,r_trials_vec)
    spikes = np.zeros((runTime,))
    successes = 0
    for i in range(runTime):
        if (np.random.rand(1) < success_probability[i]):
            successes += 1
            if (successes==r_trials):
                spikes[i] = True
                successes = 0
    #print(spikes.sum()*1000/runTime)
    new_spike_times = np.where(spikes)[0]
    new_spike_times += start_step
    spike_times[index] = np.append(spike_times[index],new_spike_times)
    
    
def add_gaussian_input(value,max_firing_rate,min_firing_rate,start_time,stop_time,size,sg_spike_times,time_step,
                       r_trials=1,std_dev=1,min_firing_threshold = 5,plot_list=[]):
    '''
    add spacially gaussian shaped input spike train to the spike generator spike times list
    input is a group of spacially gaussian distributed renewal spike trains with a given duration and 
    a given space coded value as mean of the gaussian.
    spike trains are generated with renewal process implementing negative binomial distribution
    Args:
        value: space coded value as input
        max_firing_rate: max firing rate of the gaussian input
        min_firing_rate: background firing rate 
        start_time, stop_time: start and end times (in milliseconds)
        sg_spike_times: list of [sg size] np arrays of spike times for each sg port (sg = spike gen)
        time_step: "physical" value of time stepo
        r_trials: actually refractory period..., for regular spikes set r_trials=None
        min_firing_threshold: min allowed firing rate
        plot_list: list of tuples containint timestesps and values for plotting
    '''
    x = np.arange(0,size)
    firing_rates = min_firing_rate + normal1d_density(x,value,std_dev,False)*(max_firing_rate-min_firing_rate)
    firing_rates = np.where(firing_rates>min_firing_threshold,firing_rates,-1000)#set to -1 non allowed firing rates
    firing_period_steps = np.rint(1000/firing_rates/time_step) #conversion in period, in steps, round to int
    #plt.plot(firing_period_steps)
    for i in range(size):  #for each slot of spike gen add spike trains
        if (firing_period_steps[i]>0):
            append_renewal_spikes(i,sg_spike_times,int(start_time/time_step),int(stop_time/time_step),
                                  r_trials,firing_period_steps[i])
            
    #add input to the plot list
    add_plot_costant(plot_list,int(start_time/time_step),int(stop_time/time_step),value)
        
def add_input_vector(input_vector,max_firing_rate,min_firing_rate,start_time,elment_duration,size,sg_spike_times,time_step,
                       r_trials=1,std_dev=1,min_firing_threshold = 5):
    '''
    add series of spacially gaussian shaped input spike train to the spike generator spike times list,
    input values are given in a vector, each value input has a duration of elment_duration steps
    Uses renmewal spike trains
    Args:
        input_vector: space coded series of values as input
        max_firing_rate: max firing rate of the gaussian input
        min_firing_rate: background firing rate 
        start_step: start of the series of inputs (in milliseconds)
        elment_duration: duration of each value input of the the input_vector (in ms)

        sg_spike_times: list of [sg size] np arrays of spike times for each sg port (sg = spike gen)
        time_step: "physical" value of time stepo
        r_trials: actually refractory period..., for regular spikes set r_trials=None
        min_firing_threshold: min allowed firing rate
    '''
    run_time = elment_duration*input_vector.size
    x=np.zeros((size,run_time))
    for i in range(run_time):
        x[:,i] = abs(np.arange(0, size, 1) - input_vector[i//elment_duration])
    firing_rates = min_firing_rate + normal1d_density(x,0,std_dev,False)*(max_firing_rate-min_firing_rate)
    firing_rates = np.where(firing_rates>min_firing_threshold,firing_rates,-1000)#set to negative non allowed firing rates
    firing_period_steps = np.rint(1000/firing_rates/time_step) #conversion in period, in steps, round to int
    for i in range(size):  #for each slot of spike gen add spike trains
        append_renewal_spikes(i,sg_spike_times,int(start_time/time_step),int((run_time+start_time)/time_step),
                             r_trials,firing_period_steps[i])
    
    
def add_plot_costant(plot_list,start_time,stop_time,value):
    #add a constant plot from a start time to a stop time to the plot_list
    #adds a tuple containing timestamp array and value array
    plot_list.append(([start_time,stop_time],[value,value]))


#PLOTTING
def spike_times_to_fake_spike_probes(inputSpikeTimes,runtime,wta_size):
    """WARNING, this is a hack. Converts a list of spike times to a list of spike-probe-like elements, each with attribute
       .data, with same properies as real spike probe data. The only reason to do that is to be able do use 
        make_firing_rate_matrix() function on input spike times (without having to change this function for backwards
        compatibility). This is only a quick fix sorry...
        Args:
            input_spike_times: list of spike lists for each sg port
            runtime: lenght of simulation
    """
    class FakeSpikeProbe:
        pass
    fake_spike_probes = []
    for i in range(wta_size):
        data = np.zeros((runtime,))
        for timestap in inputSpikeTimes[i]:
            data[timestap] = 1
        sp = FakeSpikeProbe()
        sp.data = data
        fake_spike_probes.append(sp)
    return fake_spike_probes

def make_firing_rate_matrix(wta_size,elapsed_time,spike_probes,filter_width,filter_std_dev=1.0,filt_type='box',hertz=False,time_step=1):
    """
    computes the instantaneous firing rates from the probes and put them in a matrix wta_size x elapsed_time
    Args:
        wta_size: size of the wta
        elapsed_time: how many steps there are in the spike_probes
        spike_probes: spike probe object
        filter_width: with of box filter (if filt='box')
        filter_std_dev: std dev of gaussina filter (if filt='gaussian')
        filt: type of filter, 'box' or 'gaussian'
        hertz: bool, convert into pysical hertz
        time_step: well time step
    Returns:
        inst_firing_rate: matrix of firing rates (wta_size x elapsed_time)
    """
    #N = 50
    filt = np.ones((filter_width,))/filter_width #filt = makeGaussian1D(N,N/2,N/2)/N
    inst_firing_rate = np.zeros((wta_size,elapsed_time))
    #WTA
    for i in range(wta_size):
        spikes = np.array(spike_probes[i].data)*1.0
        if (filt_type=='gaussian'):
            filtered_rate = ndimage.filters.gaussian_filter1d(spikes,filter_std_dev)
        else:
            filtered_rate = np.convolve(spikes,filt,mode='full')#, mode='valid')
        filtered_rate.resize(elapsed_time)
        inst_firing_rate[i] = filtered_rate
        
    if (hertz):    
        inst_firing_rate *= 1000*time_step #convert into hertz
    return inst_firing_rate

def make_population_vector(wta_size,elapsed_time,inst_firing_rate):
    """
    computes the population vector (position of peak) at each time step from the instantaneous firing rate matrix
    Args:
        wta_size:
        elapsed_time:
        inst_firing_rate: matrix returned by make_firing_rate_matrix()
    Returns:
        population_vector: vector of the position of the peak at each time step
    """
        
    activation_integral = np.zeros((elapsed_time))
    population_vector = np.zeros((elapsed_time))
    for i in range(wta_size):
        activation_integral += inst_firing_rate[i] #integrate total "firing rate" = activation, used for normalization
        population_vector += (i)*inst_firing_rate[i]
    activation_integral = np.where(activation_integral != 0,activation_integral,1)
    population_vector = population_vector / activation_integral #normalization (elementwise division)

    return population_vector

def split_population_vector(population_vector,max_rates,min_rate_strong,min_rate_weak):
    """split population vector into two masked arrays,  population_vector_strong where peak firing rate above 
        min_rate_strong, and population_vector_weak: where peak firing rate is between min_rate_strong and min_rate_weak
        population_vector: already computed pop vec
        max_rates: array of peak firing rate 
    """
    population_vector_strong = np.ma.masked_where(max_rates < min_rate_strong , population_vector)
    population_vector_weak = np.ma.masked_where((max_rates > min_rate_strong)|(max_rates < min_rate_weak),population_vector)   
    return  population_vector_strong,population_vector_weak

#SETTING PARAMETERS

def create_compartment_prototype(time_step,tau_current_decay,tau_voltage_decay,threshold_voltage_mant=1000, min_voltage_exp=16,enable_backprop = True,logicalCoreId=None):
    """
    Creates a compartment prototype object, taking "physical" parameters
    and converting them in harware time steps

    Args:
        time_step: physical value of the time step (in milliseconds)        
        current_decay: tau (in milliseconds)
        voltage_decay: tau (in milliseconds)
        threshold_voltage: actual threshold value = threshold_voltage*2^6
        min_voltage_exp: #actual minimum voltage is -2**min_voltage_exp
    Returns:
        cx_proto: compartment prototype object
    """ 

    #Conversion in hardware steps. Threshold and minimum voltage do not need to be converted
    tau_current_decay_steps = tau_current_decay/time_step
    tau_voltage_decay_steps = tau_voltage_decay/time_step
    
    # Create compartment prototype
    #For the post synaptic traces to be
    # updated we need to enable the back propagation of action potential whenever the compartment spikes.
    if (logicalCoreId==None):
        cx_proto = nx.CompartmentPrototype(vThMant=threshold_voltage_mant,
                                          compartmentVoltageDecay = int(1/tau_voltage_decay_steps*2**12),
                                          compartmentCurrentDecay = int(1/tau_current_decay_steps*2**12),
                                          vMinExp = min_voltage_exp,
                                          enableSpikeBackprop = int(enable_backprop),
                                          enableSpikeBackpropFromSelf = int(enable_backprop))
    else:
        cx_proto = nx.CompartmentPrototype(vThMant=threshold_voltage_mant,
                                          compartmentVoltageDecay = int(1/tau_voltage_decay_steps*2**12),
                                          compartmentCurrentDecay = int(1/tau_current_decay_steps*2**12),
                                          vMinExp = min_voltage_exp,
                                          enableSpikeBackprop = int(enable_backprop),
                                          enableSpikeBackpropFromSelf = int(enable_backprop),
                                          logicalCoreId=logicalCoreId)
         
    
    return cx_proto


def create_wta_spike_gen(size,time_step,weight_min,weight_max,delay,std_dev,compartments,conn_proto,net,distribution='gaussian'):
    """
    Creates spike generator for a wta 1d. (gaussian connections OR identity connections)
    Weight and delay physical values

    Args:
        size: size of the wta
        time_step: physical value of the time step (in milliseconds)
        weight: will be scaled
        delay: will be scaled
        std_dev: standard deviation of the gaussian, if set to 0 use identity mapping instead
        compartments: compartments loihi object
        conn_proto: connection prototype object
        distribution: 'gaussian' or 'triangle' or mexican thingy
        
    Returns:
        wta_spike_gen: spike generator object
    """ 
    if (std_dev==0):
        w_matrix=np.identity(size)
        if (weight_min==0):
            m_matrix=np.identity(size) #mask
        else:
            m_matrix=np.ones((size,size))
        w_matrix *= (weight_max-weight_min)*time_step
        w_matrix += weight_min*time_step
    else:
        w_matrix = make_lateral_connections(size,std_dev,0,weight_min*time_step,weight_max*time_step,distribution,True)
        m_matrix=np.where(w_matrix != 0 ,1,0)
    
    d_matrix=np.zeros((size,size))

    d_matrix *= delay*time_step    
    print(w_matrix)# print(m_matrix)
    
    wta_spike_gen = net.createSpikeGenProcess(numPorts=size)
    
    wta_spike_gen.connect(compartments, 
                      prototype=conn_proto, 
                      weight=w_matrix,
                      delay=d_matrix,
                      connectionMask=m_matrix)
    
    return wta_spike_gen

def add_spikes_to_gen(size,input_spikes,spike_gen):
    """
    Add spikes to spike generator

    Args:
        size: of the wta
        input_spikes:list (size) of np.arrays containing the spike times for every generator slot
        
    Returns:
        input_spike_times: list of lists of spike times
    """ 
    input_spike_times = []
    for i in range(size):
        st = input_spikes[i].tolist()
        input_spike_times.append(st)
        spike_gen.addSpikes(spikeInputPortNodeIds=i, 
                     spikeTimes=st)
        
    return input_spike_times

#Classes------------------------------------------------------------------------


class WtaNet:
    """
    Create and manages an one dimensional wta
    All time-related parameters have to be given in milliseconds
    Intenal variables with _hw are expressed relative to the hardware time step
    

    Attributes:
      Args:
        net: loihi net (nx.NxNet())
        size: size of the wta in neurons
        
        kernel: 'gaussian', 'mexican' or 'mexican2'
        standard_deviation: standard deviation of gaussian kernel for lateral connections.
                            The gaussian function is computed using a distance matrix
        weight_max: maximum weight of excitatory connections
        weight_min_global: minimum weight of inhibitory connections (negative value) (shifts everything down)
        weight_min_peak: (ONLY used if kerlen='mexican2') minimum weight of the negative peaks of the mexican hat function
        self_excitation(bool): toggles self excitatory connections
        delay: synaptic delay (in milliseconds)
        
        time_step: physical value of the time step (in milliseconds)
        
        compartment_proto: compartment prototype object
        
      Not Args :) :       
        compartments: compartment group (loihi) object
        connections: connections (loihi) object
        w_matrix: weight matrix
        d_matrix: delay matrix     
        probes: dictionary of probes
        
    """

    def __init__(self,
                 net,                 
                 size,
                 kernel,
                 standard_deviation,
                 weight_min_peak,
                 weight_min_global,
                 weight_max,
                 self_excitation=True,
                 delay = 1,
                 
                 time_step = 1,
                 
                 compartments_proto = None,
                ):
        
        self.net = net
        self.size = size
        
        #later connections parameters
        self.kernel = kernel
        self.standard_deviation = standard_deviation
        self.weight_min_peak = weight_min_peak
        self.weight_min_peak_hw = weight_min_peak*time_step
        self.weight_min_global = weight_min_global
        self.weight_min_global_hw = weight_min_global*time_step
        self.weight_max = weight_max
        self.weight_max_hw = weight_max*time_step
        self.self_excitation = self_excitation
        self.delay = delay
        self.delay_hw = delay/time_step
        
        self.time_step = time_step
        
        self.compartments_proto = compartments_proto
        
        #create prototypes
        self._create_prototypes()
        
    def print_parameters(self):
        print("size: ", self.size)
        print("standard_deviation: ", self.standard_deviation)
        print("weight_max: ", self.weight_max)
        print("weight_min: ", self.weight_min)
        print("self_excitation: ", self.self_excitation)
        print("time-step: ",self.time_step)
        
        
    def create(self,lateral_connections = True):
        """
        creates neurons (compartments) and lateral connections of wta
            
        Returns:
            compartments and connections objects
            w_matrix: matrix of the connections
        """
        self.compartments = self.net.createCompartmentGroup(size=self.size, prototype=self.compartments_proto)
        
        #make connection matrix
        self.d_matrix = self.delay_hw*np.ones((self.size,self.size)) #delay all 1
        self.w_matrix = make_lateral_connections(self.size,
                                            self.standard_deviation,
                                            self.weight_min_peak_hw,
                                            self.weight_min_global_hw,
                                            self.weight_max_hw,
                                            self.kernel,
                                            self.self_excitation)
        self.connections = None
        if (lateral_connections):
            self.connections = self.compartments.connect(self.compartments, 
                                                         prototype=self.conn_proto_mix, 
                                                         weight=self.w_matrix,
                                                         delay=self.d_matrix)
        
        return self.compartments,self.connections,self.w_matrix
    
    def create_probes(self,voltage_and_current=False):
        """
        creates probes for the compartments
        
        Args:
            voltage_and_current(bool): wether probe also current and voltage or only spikes (to avoid unecessary probes)
            
        Returns:
            probes (dictionary): contains (current, voltage) and spike probes at keys 'cProbeWTA', 'vProbeWTA','sProbeWTA'
        """
            
        #define probes
        self.probes = {}
        
        if voltage_and_current:
            probe_list = self.compartments.probe([nx.ProbeParameter.COMPARTMENT_CURRENT,
                                                nx.ProbeParameter.COMPARTMENT_VOLTAGE,
                                                nx.ProbeParameter.SPIKE])
            self.probes['cProbeWTA'] = probe_list[0]
            self.probes['vProbeWTA'] = probe_list[1]
            self.probes['sProbeWTA'] = probe_list[2]
        else:
            probe_list = self.compartments.probe([nx.ProbeParameter.SPIKE])
            self.probes['sProbeWTA'] = probe_list[0]
        
        return self.probes
       
    #Private methods----------------------------------------
    
    def _create_prototypes(self):

        """
        creates connection prototypes... doesn't make much sense to have a funtion for that now
        
        """
        self.conn_proto_mix = nx.ConnectionPrototype(signMode=nx.SYNAPSE_SIGN_MODE.MIXED,enableLearning=0)
        
 
       
    


    